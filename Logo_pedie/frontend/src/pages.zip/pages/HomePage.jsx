import React from 'react';
import Navbar from './home/Navbar';
import Hero from './home/Hero';
import Stats from './home/Stats';
import Features from './home/Features';
import HowItWorks from './home/HowItWorks';
import Audiences from './home/Audiences';
import Testimonials from './home/Testimonials';
import CTA from './home/CTA';
import Footer from './home/Footer';
import { CREAM } from '../constants/colors';
import '../styles/globalStyles';

export default function HomePage({ onNavigateToEditor }) {
  return (
    <div style={{ minHeight: "100vh", background: CREAM, fontFamily: "'Atkinson Hyperlegible', sans-serif", position: 'relative' }}>
      {onNavigateToEditor && (
        <button onClick={onNavigateToEditor} style={{ position: 'fixed', right: 20, top: 20, zIndex: 2000, background: '#1e40af', color: 'white', border: 'none', padding: '10px 14px', borderRadius: 8, cursor: 'pointer' }}>Commencer</button>
      )}
      
      <Navbar />
      <Hero />
      <Stats />
      <Features />
      <HowItWorks />
      <Audiences />
      <Testimonials />
      <CTA />
      <Footer />
    </div>
  );
}