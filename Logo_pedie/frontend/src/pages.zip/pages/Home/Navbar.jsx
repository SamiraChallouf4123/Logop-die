import React, { useState, useEffect } from 'react';
import { TEAL, DARK } from '../../constants/colors';
import { NAV_LINKS } from '../../constants/content';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 100,
      background: scrolled ? "rgba(253,251,245,0.95)" : "transparent",
      backdropFilter: scrolled ? "blur(12px)" : "none",
      boxShadow: scrolled ? "0 1px 20px rgba(0,0,0,0.06)" : "none",
      transition: "all 0.3s ease",
      padding: "0 2rem",
    }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 68 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 14,
            background: `linear-gradient(135deg, ${TEAL}, #0F6E56)`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 20, boxShadow: `0 4px 14px ${TEAL}44`,
          }}>📖</div>
          <div>
            <div style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: "1.1rem", color: DARK }}>
              LexiAide
            </div>
            <div style={{ fontSize: "0.7rem", color: "#888", lineHeight: 1 }}>Lecture & Écriture IA</div>
          </div>
        </div>

        <div style={{ display: "flex", gap: "2rem", alignItems: "center" }}>
          {NAV_LINKS.map((l) => (
            <a key={l} href="#" className="nav-link" style={{
              fontSize: "0.9rem", color: "#444", textDecoration: "none",
              fontWeight: 500, transition: "color 0.2s",
            }}>{l}</a>
          ))}
          <a href="#" style={{
            background: DARK, color: "#fff", padding: "0.5rem 1.2rem",
            borderRadius: 50, fontSize: "0.88rem", fontWeight: 700,
            fontFamily: "'Nunito', sans-serif", textDecoration: "none",
            boxShadow: `0 4px 14px rgba(26,26,46,0.2)`,
            transition: "transform 0.2s",
          }}>Essai gratuit</a>
        </div>
      </div>
    </nav>
  );
}
